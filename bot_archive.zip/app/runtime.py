from __future__ import annotations

import asyncio
import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import CallbackQuery, Message
from dotenv import dotenv_values, load_dotenv

from .catalog import FlowCatalog
from .constants import DEFAULT_LINKS
from .context import AppContext
from .handlers.admin import build_admin_router
from .keyboards import kb_admin_order_confirm
from .overrides import RuntimeOverrides, apply_state_overrides
from .rates import RateService
from .renderer import action_token, send_state
from .storage import OrdersStore, SettingsStore, UsersStore
from .utils import parse_admin_ids, parse_non_negative_amount, safe_username

PAYMENT_PROOF_PROMPT = "📸 Прикрепите фото успешной оплаты. После отправки заявка уйдет в админку."
PAYMENT_PROOF_NEED_PHOTO = "Прикрепите именно фото успешной оплаты (чек/скрин)."
PAYMENT_PROOF_SENT = "✅ Фото получено. Заявка передана в админку."
PAYMENT_PROOF_STORED = "✅ Фото получено. Админы пока не настроены, заявка сохранена локально."

RUB_AMOUNT_RE = re.compile(r"([0-9][0-9\s.,]{1,})\s*(?:RUB|руб)", re.IGNORECASE)
COIN_AMOUNT_RE = re.compile(
    r"([0-9]+(?:[.,][0-9]+)?)\s*(BTC|LTC|XMR|USDT|ETH|TRX|TON)\b",
    re.IGNORECASE,
)
WALLET_RE = re.compile(r"(?:кошелек|кошел[её]к|wallet)\s*:?\s*([^\n]+)", re.IGNORECASE)


@dataclass
class UserSession:
    state_id: str
    history: list[str] = field(default_factory=list)
    awaiting_payment_proof: bool = False
    payment_context: str = ""
    selected_payment_method: str = ""


class FlowRuntime:
    def __init__(
        self,
        *,
        project_dir: Path,
        catalog: FlowCatalog,
        app_context: AppContext,
    ):
        self.project_dir = project_dir
        self.raw_dir = project_dir / "data" / "raw"
        self.media_dir = project_dir / "data" / "media"
        self.catalog = catalog
        self.app_context = app_context
        self.sessions: dict[int, UserSession] = {}
        self.action_tokens: dict[str, str] = {}
        self.token_actions: dict[str, str] = {}
        self.payment_proofs_path = project_dir / "data" / "admin" / "payment_proofs.json"
        self._ensure_payment_proofs_file()

    def token_for_action(self, action_text: str) -> str:
        existing = self.action_tokens.get(action_text)
        if existing:
            return existing
        token = action_token(action_text)
        self.action_tokens[action_text] = token
        self.token_actions[token] = action_text
        return token

    async def start(self, msg: Message) -> None:
        user = msg.from_user
        if user is None:
            return
        user_id = int(user.id)
        start_sid = self.catalog.start_state_id
        session = UserSession(state_id=start_sid, history=[start_sid])
        self.sessions[user_id] = session
        await self._send_state_by_id(msg, start_sid, session=session)

    async def on_callback(self, cb: CallbackQuery) -> None:
        user = cb.from_user
        if user is None:
            await cb.answer()
            return

        token = str(cb.data or "")
        action_text = self.token_actions.get(token, "")
        if not action_text:
            await cb.answer()
            return

        callback_message = cb.message if isinstance(cb.message, Message) else None

        session = self.sessions.get(int(user.id))
        if session is None:
            if callback_message is not None:
                await self.start(callback_message)
            await cb.answer()
            return

        selected_method = self._match_payment_method(action_text)
        if selected_method:
            session.selected_payment_method = selected_method

        if action_text == "✅ Я оплатил" and callback_message is not None:
            session.awaiting_payment_proof = True
            session.payment_context = self._state_text(session.state_id)
            await callback_message.answer(PAYMENT_PROOF_PROMPT)
            await cb.answer()
            return

        next_state = self.catalog.resolve_action(session.state_id, action_text)
        if next_state and callback_message is not None:
            session.state_id = next_state
            session.history.append(next_state)
            session.awaiting_payment_proof = False
            await self._send_state_by_id(callback_message, next_state, session=session)
            await self._send_system_chain(callback_message, session)

        await cb.answer()

    async def on_message(self, msg: Message) -> None:
        user = msg.from_user
        if user is None:
            return

        text = str(msg.text or "").strip()
        if text.startswith("/"):
            return

        user_id = int(user.id)
        session = self.sessions.get(user_id)
        if session is None:
            await self.start(msg)
            return

        if session.awaiting_payment_proof:
            await self._handle_payment_proof(msg, session)
            return

        selected_method = self._match_payment_method(text)
        if selected_method:
            session.selected_payment_method = selected_method

        next_state = self.catalog.resolve_action(session.state_id, text)
        if next_state is None and self.catalog.state_accepts_input(session.state_id):
            next_state = self.catalog.resolve_action(session.state_id, text, is_text_input=True)

        if not next_state:
            return

        session.state_id = next_state
        session.history.append(next_state)
        session.awaiting_payment_proof = False
        await self._send_state_by_id(msg, next_state, session=session)
        await self._send_system_chain(msg, session)

    async def _handle_payment_proof(self, msg: Message, session: UserSession) -> None:
        photos = list(msg.photo or [])
        if not photos:
            await msg.answer(PAYMENT_PROOF_NEED_PHOTO)
            return

        user = msg.from_user
        if user is None:
            return

        photo_file_id = photos[-1].file_id
        order = self._create_paid_order(user_id=int(user.id), username=(user.username or ""), session=session)
        order_id = order["order_id"]

        caption = self._build_admin_caption(
            order_id=order_id,
            user_id=int(user.id),
            username=(user.username or ""),
            order_context=session.payment_context,
        )

        forwarded = await self._forward_payment_to_admins(
            msg=msg,
            photo_file_id=photo_file_id,
            caption=caption,
            order_id=order_id,
        )

        self._append_payment_proof(
            user_id=int(user.id),
            username=(user.username or ""),
            order_id=order_id,
            order_context=session.payment_context,
            photo_file_id=photo_file_id,
            forwarded_to_admins=forwarded,
        )

        session.awaiting_payment_proof = False
        session.payment_context = ""

        if forwarded:
            await msg.answer(PAYMENT_PROOF_SENT)
        else:
            await msg.answer(PAYMENT_PROOF_STORED)

    async def _forward_payment_to_admins(
        self,
        *,
        msg: Message,
        photo_file_id: str,
        caption: str,
        order_id: str,
    ) -> bool:
        bot = msg.bot
        if bot is None:
            return False

        forwarded = False
        for admin_id in self.app_context.admin_ids:
            try:
                await bot.send_photo(
                    chat_id=admin_id,
                    photo=photo_file_id,
                    caption=caption,
                    parse_mode=None,
                    reply_markup=kb_admin_order_confirm(order_id),
                )
                forwarded = True
            except Exception:
                continue
        return forwarded

    def _create_paid_order(self, *, user_id: int, username: str, session: UserSession) -> Any:
        details = self._extract_order_details(session.payment_context)

        payment_method = session.selected_payment_method or self._default_payment_method()
        bank = self._effective_bank_for_session(session, session.state_id)
        order = self.app_context.orders.create_order(
            user_id=user_id,
            username=username,
            wallet=details["wallet"],
            coin_symbol=details["coin_symbol"],
            coin_amount=details["coin_amount"],
            amount_rub=details["amount_rub"],
            payment_method=payment_method,
            bank=bank,
        )
        self.app_context.orders.mark_paid(order["order_id"])
        return order

    def _extract_order_details(self, text: str) -> dict[str, Any]:
        amount_rub = 0.0
        coin_amount = 0.0
        coin_symbol = "BTC"
        wallet = "(не указан)"

        rub_matches = RUB_AMOUNT_RE.findall(text or "")
        if rub_matches:
            parsed_rub = _parse_decimal(rub_matches[-1])
            if parsed_rub is not None:
                amount_rub = parsed_rub

        coin_matches = COIN_AMOUNT_RE.findall(text or "")
        if coin_matches:
            coin_amount_raw, coin_symbol_raw = coin_matches[-1]
            parsed_coin = _parse_decimal(coin_amount_raw)
            if parsed_coin is not None:
                coin_amount = parsed_coin
            coin_symbol = coin_symbol_raw.upper()

        wallet_match = WALLET_RE.search(text or "")
        if wallet_match:
            wallet_value = wallet_match.group(1).strip()
            if wallet_value:
                wallet = wallet_value

        return {
            "amount_rub": amount_rub,
            "coin_amount": coin_amount,
            "coin_symbol": coin_symbol,
            "wallet": wallet,
        }

    def _ensure_payment_proofs_file(self) -> None:
        self.payment_proofs_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.payment_proofs_path.exists():
            self.payment_proofs_path.write_text("[]\n", encoding="utf-8")

    def _append_payment_proof(
        self,
        *,
        user_id: int,
        username: str,
        order_id: str,
        order_context: str,
        photo_file_id: str,
        forwarded_to_admins: bool,
    ) -> None:
        try:
            payload = json.loads(self.payment_proofs_path.read_text(encoding="utf-8"))
        except Exception:
            payload = []

        if not isinstance(payload, list):
            payload = []

        payload.append(
            {
                "user_id": int(user_id),
                "username": username,
                "order_id": order_id,
                "order_context": order_context,
                "photo_file_id": photo_file_id,
                "forwarded_to_admins": bool(forwarded_to_admins),
            }
        )

        self.payment_proofs_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    async def _send_state_by_id(self, msg: Message, state_id: str, *, session: UserSession | None) -> None:
        base_state = self.catalog.states.get(state_id)
        if not base_state:
            return

        overrides = RuntimeOverrides(
            operator_url=self.app_context.settings.link("operator"),
            payment_requisites=self._effective_requisites_for_state(session, state_id),
            link_overrides=self.app_context.settings.all_links(),
            sell_wallet_overrides=self.app_context.settings.all_sell_wallets(),
            commission_percent=self.app_context.settings.commission_percent,
        )
        live_rates_rub = await self._get_live_rates_rub()
        state = apply_state_overrides(
            state=base_state,
            overrides=overrides,
            operator_url_aliases=self.catalog.operator_url_aliases,
            operator_handle_aliases=self.catalog.operator_handle_aliases,
            detected_requisites=self.catalog.detected_requisites,
            link_url_aliases=self.catalog.link_url_aliases,
            sell_wallet_aliases=self.catalog.sell_wallet_aliases,
            live_rates_rub=live_rates_rub,
        )

        await send_state(
            msg,
            state,
            media_dir=self.media_dir,
            token_by_action=self.token_for_action,
        )

    async def _send_system_chain(self, msg: Message, session: UserSession, max_hops: int = 4) -> None:
        seen: set[str] = {session.state_id}
        current = session.state_id
        hops = 0

        while hops < max_hops:
            if self.catalog.state_has_buttons(current):
                break
            next_state = self.catalog.resolve_system_next(current)
            if not next_state or next_state in seen:
                break
            seen.add(next_state)
            session.state_id = next_state
            session.history.append(next_state)
            await self._send_state_by_id(msg, next_state, session=session)
            current = next_state
            hops += 1

    def _state_text(self, state_id: str) -> str:
        state = self.catalog.states.get(state_id) or {}
        return str(state.get("text") or "")

    def _build_admin_caption(
        self,
        *,
        order_id: str,
        user_id: int,
        username: str,
        order_context: str,
    ) -> str:
        lines = [
            "Новая оплата от пользователя",
            f"order_id: {order_id}",
            f"user_id: {user_id}",
            f"username: {safe_username(username)}",
        ]
        context = (order_context or "").strip()
        if context:
            lines.append("")
            lines.append("Контекст заявки:")
            lines.append(context[:1200])
        return "\n".join(lines)

    async def _get_live_rates_rub(self) -> dict[str, float]:
        rates = await self.app_context.rates.get_rates()
        return {
            "BTC": float(rates.get("btc", 0.0)),
            "LTC": float(rates.get("ltc", 0.0)),
            "XMR": float(rates.get("xmr", 0.0)),
            "USDT": float(rates.get("usdt", 0.0)),
        }

    def _effective_requisites_for_state(self, session: UserSession | None, state_id: str) -> str:
        settings = self.app_context.settings
        if settings.requisites_mode == "single":
            return settings.requisites_value

        if session and session.selected_payment_method:
            _, value = settings.method_requisites(session.selected_payment_method)
            if value.strip():
                return value

        state = self.catalog.states.get(state_id) or {}
        text_blob = "\n".join(
            [
                str(state.get("text") or ""),
                str(state.get("text_html") or ""),
                str(state.get("text_markdown") or ""),
            ]
        ).lower()
        matches: list[str] = []
        for method in settings.payment_methods():
            if method.lower() in text_blob:
                matches.append(method)
        if len(matches) == 1:
            _, value = settings.method_requisites(matches[0])
            if value.strip():
                return value

        return settings.requisites_value

    def _effective_bank_for_session(self, session: UserSession | None, state_id: str) -> str:
        settings = self.app_context.settings
        if settings.requisites_mode == "single":
            return settings.requisites_bank

        if session and session.selected_payment_method:
            bank, _ = settings.method_requisites(session.selected_payment_method)
            if bank.strip():
                return bank

        state = self.catalog.states.get(state_id) or {}
        text_blob = "\n".join(
            [
                str(state.get("text") or ""),
                str(state.get("text_html") or ""),
                str(state.get("text_markdown") or ""),
            ]
        ).lower()
        for method in settings.payment_methods():
            if method.lower() in text_blob:
                bank, _ = settings.method_requisites(method)
                if bank.strip():
                    return bank

        return settings.requisites_bank

    def _match_payment_method(self, action_text: str) -> str:
        action = (action_text or "").strip().lower()
        if not action:
            return ""
        for method in self.app_context.settings.payment_methods():
            if method.lower() == action:
                return method
        return ""

    def _default_payment_method(self) -> str:
        methods = self.app_context.settings.payment_methods()
        if methods:
            return methods[0]
        return "Перевод на карту"


def outgoing_text_from_state(catalog: FlowCatalog, state_id: str) -> str:
    state = catalog.states[state_id]
    return str(state.get("text") or "")


def _parse_decimal(raw: str) -> float | None:
    cleaned = (raw or "").replace("\u00a0", " ").replace(" ", "").replace(",", ".")
    cleaned = re.sub(r"[^0-9.]", "", cleaned)
    if not cleaned or cleaned.count(".") > 1:
        return None
    try:
        return float(cleaned)
    except ValueError:
        return None


def _build_env_links(env: dict[str, Any], default_operator_url: str) -> dict[str, str]:
    links = dict(DEFAULT_LINKS)
    if default_operator_url.strip():
        links["operator"] = default_operator_url.strip()

    for link_key in DEFAULT_LINKS:
        env_key = f"{link_key.upper()}_LINK"
        value = str(env.get(env_key) or "").strip()
        if value:
            links[link_key] = value
    return links


async def amain() -> None:
    project_dir = Path(__file__).resolve().parents[1]
    env_path = project_dir / ".env"
    load_dotenv(env_path, override=True)

    bot_token = (os.getenv("BOT_TOKEN") or "").strip()
    if not bot_token:
        raise RuntimeError("BOT_TOKEN is empty")

    catalog = FlowCatalog.from_directory(
        raw_dir=project_dir / "data" / "raw",
        media_dir=project_dir / "data" / "media",
    )

    env = dotenv_values(env_path)
    admin_ids = parse_admin_ids(str(env.get("ADMIN_IDS") or ""))
    default_commission = parse_non_negative_amount(str(env.get("DEFAULT_COMMISSION_PERCENT") or ""))
    if default_commission is None or default_commission < 0 or default_commission > 50:
        default_commission = 2.5

    settings_store = SettingsStore(
        path=project_dir / "data" / "admin" / "settings.json",
        default_commission=default_commission,
        env_links=_build_env_links(env, catalog.default_operator_url),
    )
    users_store = UsersStore(project_dir / "data" / "admin" / "users.json")
    orders_store = OrdersStore(project_dir / "data" / "admin" / "orders.json")
    rate_service = RateService(ttl_seconds=45)

    app_context = AppContext(
        settings=settings_store,
        users=users_store,
        orders=orders_store,
        rates=rate_service,
        admin_ids=admin_ids,
        env_path=env_path,
    )

    runtime = FlowRuntime(
        project_dir=project_dir,
        catalog=catalog,
        app_context=app_context,
    )

    dp = Dispatcher(storage=MemoryStorage())
    
    # Admin router must be included first or the catch-all @dp.message() will intercept its commands
    dp.include_router(build_admin_router(app_context))

    main_router = Router(name="main")

    @main_router.message(CommandStart())
    async def _start(message: Message) -> None:
        await runtime.start(message)

    @main_router.callback_query(F.data.startswith("a:"))
    async def _callback(cb: CallbackQuery) -> None:
        await runtime.on_callback(cb)

    @main_router.message()
    async def _message(message: Message) -> None:
        if (message.text or "").strip() == "/start":
            await runtime.start(message)
            return
        await runtime.on_message(message)

    dp.include_router(main_router)

    bot = Bot(token=bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    await dp.start_polling(bot)


def run() -> None:
    asyncio.run(amain())
